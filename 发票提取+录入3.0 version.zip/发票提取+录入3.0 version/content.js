// Content Script - 在ERP页面中运行，负责实际填充表单

console.log('✅ Content script 已加载');

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('收到消息:', request);
  
  if (request.action === 'ping') {
    sendResponse({ success: true, message: 'Content script is ready' });
    return true;
  }
  
  if (request.action === 'fillInvoice') {
    fillInvoiceData(request.data)
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
});

async function fillInvoiceData(invoice) {
  try {
    // 1. 填写开票日期
    await fillInvoiceDate(invoice['开票日期']);
    
    // 2. 填写发票号码
    await fillInvoiceNumber(invoice['发票号码']);
    
    // 3. 确保有发票明细行
    await ensureDetailRow();
    
    // 4. 填写金额
    await fillAmount(invoice['金额']);
    
    // 5. 选择发票内容
    await selectInvoiceContent();
    
    // 6. 最后触发文件上传（自动点击）
    await triggerFileUpload(invoice['发票名称']);
    
    console.log('✅ 发票数据填充完成');
  } catch (error) {
    console.error('❌ 填充失败:', error);
    throw error;
  }
}

// 填写开票日期
async function fillInvoiceDate(dateString) {
  return new Promise((resolve, reject) => {
    try {
      const dateInputs = Array.from(document.querySelectorAll('input[type="text"]'));
      const dateInput = dateInputs.find(input => {
        const label = input.closest('.el-form-item')?.querySelector('.el-form-item__label');
        return label && label.textContent.includes('开票日期');
      });

      if (!dateInput) throw new Error('未找到开票日期输入框');

      let dateFormatted;
      if (dateString.includes('年')) {
        const match = dateString.match(/(\d{4})年(\d{2})月(\d{2})日/);
        if (match) dateFormatted = `${match[1]}-${match[2]}-${match[3]}`;
      } else {
        dateFormatted = dateString;
      }

      dateInput.click();
      setTimeout(() => {
        dateInput.value = dateFormatted;
        dateInput.dispatchEvent(new Event('input', { bubbles: true }));
        dateInput.dispatchEvent(new Event('change', { bubbles: true }));
        document.body.click();
        setTimeout(resolve, 300);
      }, 500);
    } catch (error) {
      reject(error);
    }
  });
}

// 填写发票号码
async function fillInvoiceNumber(number) {
  return new Promise((resolve, reject) => {
    try {
      const inputs = Array.from(document.querySelectorAll('input[type="text"]'));
      const invoiceNumberInput = inputs.find(input => {
        const label = input.closest('.el-form-item')?.querySelector('.el-form-item__label');
        return label && label.textContent.includes('发票号码');
      });

      if (!invoiceNumberInput) throw new Error('未找到发票号码输入框');

      invoiceNumberInput.value = number.toString().trim();
      invoiceNumberInput.dispatchEvent(new Event('input', { bubbles: true }));
      invoiceNumberInput.dispatchEvent(new Event('change', { bubbles: true }));

      setTimeout(resolve, 200);
    } catch (error) {
      reject(error);
    }
  });
}

// 触发文件上传（自动点击上传按钮）
async function triggerFileUpload(fileName) {
  return new Promise((resolve) => {
    try {
      console.log('📎 准备触发文件上传:', fileName);
      
      // 延迟1.5秒，确保页面元素稳定
      setTimeout(() => {
        let fileInput = null;
        
        // 方法1：通过标签文本精确查找
        const allElements = document.querySelectorAll('*');
        for (const el of allElements) {
          if (el.textContent.trim() === '上传发票电子版' || 
              el.textContent.includes('上传发票电子版')) {
            // 查找最近的上传区域
            const uploadArea = el.closest('.el-upload') || 
                             el.parentElement?.querySelector('.el-upload');
            if (uploadArea) {
              fileInput = uploadArea.querySelector('input[type="file"]');
              if (fileInput) {
                console.log('✅ 通过标签文本找到上传按钮');
                break;
              }
            }
          }
        }
        
        // 方法2：查找所有el-upload，排除已有文件的
        if (!fileInput) {
          const uploads = document.querySelectorAll('.el-upload');
          for (const upload of uploads) {
            // 跳过已有上传文件的区域
            if (upload.querySelector('.el-upload-list__item')) continue;
            const input = upload.querySelector('input[type="file"]');
            if (input && input.accept.includes('pdf')) {
              fileInput = input;
              console.log('✅ 通过PDF类型找到上传按钮');
              break;
            }
          }
        }
        
        // 方法3：兜底 - 找最后一个file input
        if (!fileInput) {
          const allInputs = document.querySelectorAll('input[type="file"]');
          if (allInputs.length > 0) {
            fileInput = allInputs[allInputs.length - 1];
            console.log('✅ 使用最后一个file input');
          }
        }
        
        if (fileInput) {
          // 触发点击
          fileInput.click();
          console.log('✅ 已触发文件选择对话框');
          
          // 显示成功提示
          showNotification('✅ 填充完成！请选择PDF文件：' + fileName, 'success');
        } else {
          console.warn('⚠️ 未找到上传按钮');
          showNotification('⚠️ 填充完成！请手动点击"上传发票电子版"', 'warning');
        }
        
        resolve();
      }, 1500);
      
    } catch (error) {
      console.warn('文件上传触发失败:', error.message);
      resolve();
    }
  });
}

// 显示页面通知
function showNotification(message, type = 'info') {
  const colors = {
    success: '#4caf50',
    warning: '#ff9800',
    error: '#f44336',
    info: '#2196f3'
  };
  
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${colors[type]};
    color: white;
    padding: 14px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    z-index: 99999;
    font-family: 'Microsoft YaHei', sans-serif;
    font-size: 14px;
    max-width: 400px;
    animation: slideIn 0.3s ease-out;
  `;
  notification.textContent = message;
  document.body.appendChild(notification);
  
  // 添加动画
  const style = document.createElement('style');
  style.textContent = '@keyframes slideIn { from { transform: translateX(400px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }';
  document.head.appendChild(style);
  
  setTimeout(() => {
    notification.style.transition = 'opacity 0.3s, transform 0.3s';
    notification.style.opacity = '0';
    notification.style.transform = 'translateX(400px)';
    setTimeout(() => notification.remove(), 300);
  }, 5000);
}

// 确保有发票明细行
async function ensureDetailRow() {
  return new Promise((resolve) => {
    const amountInputs = document.querySelectorAll('.el-input-number input');
    const selectInputs = document.querySelectorAll('.el-select input');
    
    if (amountInputs.length > 0 && selectInputs.length > 0) {
      console.log('✅ 已存在明细行');
      resolve();
      return;
    }

    const plusIcon = document.querySelector('.index-module_basicTitle_22qEi .el-icon-plus');
    if (plusIcon) {
      plusIcon.click();
      setTimeout(resolve, 1000);
    } else {
      resolve();
    }
  });
}

// 填写金额
async function fillAmount(amount) {
  return new Promise((resolve, reject) => {
    try {
      const amountInputs = Array.from(document.querySelectorAll('.el-input-number input'));
      if (amountInputs.length === 0) throw new Error('未找到金额输入框');
      
      const amountInput = amountInputs[0];
      amountInput.value = amount.toString().trim();
      amountInput.dispatchEvent(new Event('input', { bubbles: true }));
      amountInput.dispatchEvent(new Event('change', { bubbles: true }));
      amountInput.dispatchEvent(new Event('blur', { bubbles: true }));

      setTimeout(resolve, 300);
    } catch (error) {
      reject(error);
    }
  });
}

// 选择发票内容
async function selectInvoiceContent() {
  return new Promise((resolve, reject) => {
    try {
      const table = document.querySelector('.el-table');
      if (!table) throw new Error('未找到发票明细表格');
      
      const tableSelects = Array.from(table.querySelectorAll('.el-select'));
      if (tableSelects.length === 0) throw new Error('未找到下拉框');
      
      const contentInput = tableSelects[0].querySelector('input');
      if (!contentInput) throw new Error('未找到输入框');

      contentInput.click();

      setTimeout(() => {
        const dropdowns = document.querySelectorAll('.el-select-dropdown');
        let visibleDropdown = null;
        
        for (const dropdown of dropdowns) {
          const style = window.getComputedStyle(dropdown);
          if (style.display !== 'none' && style.visibility !== 'hidden') {
            visibleDropdown = dropdown;
            break;
          }
        }
        
        if (!visibleDropdown) {
          reject(new Error('未找到下拉菜单'));
          return;
        }
        
        const options = visibleDropdown.querySelectorAll('.el-select-dropdown__item:not(.is-disabled)');
        if (options.length > 0) {
          options[0].click();
          setTimeout(resolve, 300);
        } else {
          reject(new Error('未找到选项'));
        }
      }, 800);
    } catch (error) {
      reject(error);
    }
  });
}
