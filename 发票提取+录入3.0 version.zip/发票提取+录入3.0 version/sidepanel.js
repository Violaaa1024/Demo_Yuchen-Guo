/**
 * ERP发票自动填充助手 - 侧边栏脚本
 * 支持 PDF / CSV / XLSX 文件解析
 */

console.log('sidepanel_v2.js 开始加载');
console.log('Papa 是否定义:', typeof Papa);
console.log('XLSX 是否定义:', typeof XLSX);
console.log('pdfjsLib 是否定义:', typeof pdfjsLib);

let invoicesData = [];

// DOM元素
const fileInput = document.getElementById('fileInput');
const fileName = document.getElementById('fileName');
const stats = document.getElementById('stats');
const totalCount = document.getElementById('totalCount');
const invoiceList = document.getElementById('invoiceList');
const message = document.getElementById('message');
const parseProgress = document.getElementById('parseProgress');
const progressFill = document.getElementById('progressFill');
const currentFileEl = document.getElementById('currentFile');
const parsedCountEl = document.getElementById('parsedCount');
const totalFilesEl = document.getElementById('totalFiles');

// 等待DOM完全加载
document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM 加载完成');
  
  // 检查库是否加载
  const missingLibs = [];
  if (typeof Papa === 'undefined') missingLibs.push('CSV解析库');
  if (typeof XLSX === 'undefined') missingLibs.push('XLSX解析库');
  if (typeof pdfjsLib === 'undefined') missingLibs.push('PDF解析库');
  
  if (missingLibs.length > 0) {
    showMessage(`❌ ${missingLibs.join('、')}加载失败，请重新加载插件`, 'error');
  }
});

// 文件选择事件
fileInput.addEventListener('change', handleFileSelect);

/**
 * 处理文件选择
 */
async function handleFileSelect(event) {
  const files = Array.from(event.target.files);
  if (files.length === 0) return;

  // 分类文件
  const pdfFiles = files.filter(f => f.name.toLowerCase().endsWith('.pdf'));
  const csvFiles = files.filter(f => f.name.toLowerCase().endsWith('.csv'));
  const xlsxFiles = files.filter(f => f.name.toLowerCase().match(/\.(xlsx|xls)$/));
  
  const fileTypeCount = [
    pdfFiles.length > 0 ? `${pdfFiles.length}个PDF` : '',
    csvFiles.length > 0 ? `${csvFiles.length}个CSV` : '',
    xlsxFiles.length > 0 ? `${xlsxFiles.length}个XLSX` : ''
  ].filter(Boolean).join('、');
  
  fileName.textContent = `已选择: ${fileTypeCount}`;
  
  // 清空之前的数据
  invoicesData = [];
  invoiceList.innerHTML = '';
  
  try {
    // 解析PDF文件
    if (pdfFiles.length > 0) {
      if (typeof pdfjsLib === 'undefined' || typeof pdfInvoiceParser === 'undefined') {
        showMessage('PDF解析库未加载，请刷新插件后重试', 'error');
        return;
      }
      await parsePDFFiles(pdfFiles);
    }
    
    // 解析CSV文件
    if (csvFiles.length > 0) {
      if (typeof Papa === 'undefined') {
        showMessage('CSV解析库未加载，请刷新插件后重试', 'error');
        return;
      }
      for (const file of csvFiles) {
        await parseCSVFile(file);
      }
    }
    
    // 解析XLSX文件
    if (xlsxFiles.length > 0) {
      if (typeof XLSX === 'undefined') {
        showMessage('XLSX解析库未加载，请刷新插件后重试', 'error');
        return;
      }
      for (const file of xlsxFiles) {
        await parseXLSXFile(file);
      }
    }
    
    // 显示结果
    if (invoicesData.length > 0) {
      stats.classList.remove('hidden');
      totalCount.textContent = invoicesData.length;
      renderInvoiceList();
      showMessage(`✅ 成功加载 ${invoicesData.length} 条发票数据`, 'success');
    } else {
      showMessage('未找到有效的发票数据', 'error');
    }
    
  } catch (error) {
    console.error('文件解析错误:', error);
    showMessage('文件解析失败: ' + error.message, 'error');
  } finally {
    // 清空input的value，这样下次选择相同文件时也会触发change事件
    event.target.value = '';
    parseProgress.classList.add('hidden');
  }
}

/**
 * 解析PDF文件
 */
async function parsePDFFiles(files) {
  console.log(`开始解析 ${files.length} 个PDF文件`);
  
  // 显示进度条
  parseProgress.classList.remove('hidden');
  totalFilesEl.textContent = files.length;
  
  const results = await pdfInvoiceParser.parseMultiple(files, (current, total, filename) => {
    parsedCountEl.textContent = current;
    currentFileEl.textContent = filename;
    progressFill.style.width = `${(current / total) * 100}%`;
  });
  
  // 过滤有效数据并添加到列表
  const validResults = results.filter(r => r['发票号码'] && r['金额']);
  
  if (validResults.length < results.length) {
    const failedCount = results.length - validResults.length;
    showMessage(`⚠️ ${failedCount} 个PDF文件解析不完整，请检查`, 'warning');
  }
  
  invoicesData.push(...results.map(r => ({
    ...r,
    _fillCount: 0
  })));
  
  console.log(`PDF解析完成，有效数据: ${validResults.length}/${results.length}`);
}

/**
 * 解析单个CSV文件
 */
function parseCSVFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = function(e) {
      let text = e.target.result;
      
      // 移除UTF-8 BOM标记
      if (text.charCodeAt(0) === 0xFEFF) {
        text = text.slice(1);
      }
      
      // 检查是否有乱码
      const hasGarbledText = /[锟斤拷�]/g.test(text);
      
      if (hasGarbledText) {
        console.warn('检测到乱码，尝试使用GBK编码...');
        const readerGBK = new FileReader();
        readerGBK.onload = function(e2) {
          let textGBK = e2.target.result;
          if (textGBK.charCodeAt(0) === 0xFEFF) {
            textGBK = textGBK.slice(1);
          }
          parseCSVText(textGBK, resolve, reject);
        };
        readerGBK.onerror = reject;
        readerGBK.readAsText(file, 'GBK');
      } else {
        parseCSVText(text, resolve, reject);
      }
    };
    
    reader.onerror = reject;
    reader.readAsText(file, 'UTF-8');
  });
}

/**
 * 解析CSV文本
 */
function parseCSVText(text, resolve, reject) {
  Papa.parse(text, {
    header: true,
    skipEmptyLines: true,
    complete: function(results) {
      console.log('CSV解析完成:', results);
      const validData = results.data
        .filter(row => getFieldValue(row, '发票号码'))
        .map(row => ({
          '发票名称': getFieldValue(row, '发票名称') || '未命名',
          '开票日期': getFieldValue(row, '开票日期') || '',
          '发票号码': getFieldValue(row, '发票号码') || '',
          '金额': getFieldValue(row, '金额') || '',
          '文件地址': getFieldValue(row, '文件地址') || '',
          '_source': 'CSV',
          _fillCount: 0
        }));
      
      invoicesData.push(...validData);
      resolve();
    },
    error: function(error) {
      console.error('CSV解析错误:', error);
      reject(error);
    }
  });
}

/**
 * 解析单个XLSX文件
 */
function parseXLSXFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = function(e) {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(firstSheet);
        
        console.log('XLSX解析完成:', jsonData);
        
        const validData = jsonData
          .filter(row => getFieldValue(row, '发票号码'))
          .map(row => ({
            '发票名称': getFieldValue(row, '发票名称') || '未命名',
            '开票日期': getFieldValue(row, '开票日期') || '',
            '发票号码': getFieldValue(row, '发票号码') || '',
            '金额': getFieldValue(row, '金额') || '',
            '文件地址': getFieldValue(row, '文件地址') || '',
            '_source': 'XLSX',
            _fillCount: 0
          }));
        
        invoicesData.push(...validData);
        resolve();
      } catch (error) {
        console.error('XLSX解析错误:', error);
        reject(error);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

/**
 * 智能获取字段值（兼容带BOM和不带BOM的列名）
 */
function getFieldValue(row, fieldName) {
  // 直接匹配
  if (row[fieldName] !== undefined) {
    return row[fieldName];
  }
  
  // 尝试匹配带BOM的列名
  const bomFieldName = '\uFEFF' + fieldName;
  if (row[bomFieldName] !== undefined) {
    return row[bomFieldName];
  }
  
  // 尝试去除所有空白字符后匹配
  const cleanFieldName = fieldName.replace(/\s/g, '');
  for (const key in row) {
    if (key.replace(/\s/g, '') === cleanFieldName) {
      return row[key];
    }
  }
  
  return undefined;
}

/**
 * 渲染发票列表
 */
function renderInvoiceList() {
  invoiceList.innerHTML = '';
  
  invoicesData.forEach((invoice, index) => {
    const item = document.createElement('div');
    item.className = 'invoice-item';
    
    const fillCountClass = invoice._fillCount > 0 ? 'success' : '';
    const sourceClass = invoice._source === 'PDF' ? 'pdf' : '';
    const hasError = invoice._error ? ' ⚠️' : '';
    
    item.innerHTML = `
      <div class="invoice-info">
        <div class="invoice-name">${invoice['发票名称']}${hasError}</div>
        <div class="invoice-number">发票号码: ${invoice['发票号码'] || '未识别'}</div>
        <div class="invoice-amount">金额: ￥${invoice['金额'] || '未识别'}</div>
        <div class="invoice-date">开票日期: ${invoice['开票日期'] || '未识别'}</div>
        <span class="invoice-source ${sourceClass}">来源: ${invoice._source}</span>
      </div>
      <div class="action-row">
        <button class="fill-btn" data-index="${index}" ${invoice._error ? 'disabled' : ''}>
          ${invoice._error ? '数据不完整' : '填充到页面'}
        </button>
        <span class="fill-count ${fillCountClass}">已填充: ${invoice._fillCount} 次</span>
      </div>
    `;
    
    invoiceList.appendChild(item);
  });

  // 绑定填充按钮事件
  document.querySelectorAll('.fill-btn:not([disabled])').forEach(btn => {
    btn.addEventListener('click', handleFillClick);
  });
}

/**
 * 确保content script已注入
 */
async function ensureContentScriptInjected(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { action: 'ping' });
    console.log('Content script 已存在:', response);
    return true;
  } catch (error) {
    console.log('Content script 未注入，正在注入...', error);
    
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
      });
      
      console.log('Content script 注入成功');
      await new Promise(resolve => setTimeout(resolve, 500));
      return true;
    } catch (injectError) {
      console.error('注入失败:', injectError);
      return false;
    }
  }
}

/**
 * 处理填充按钮点击
 */
async function handleFillClick(event) {
  const index = parseInt(event.target.dataset.index);
  const invoice = invoicesData[index];
  
  event.target.disabled = true;
  event.target.textContent = '准备中...';

  try {
    // 获取当前活动标签页
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    console.log('当前标签页:', tab);
    
    if (!tab.url.includes('erp.lightwan.com')) {
      showMessage('请在ERP页面使用此功能', 'error');
      event.target.disabled = false;
      event.target.textContent = '填充到页面';
      return;
    }

    // 确保content script已注入
    event.target.textContent = '注入脚本...';
    const injected = await ensureContentScriptInjected(tab.id);
    
    if (!injected) {
      showMessage('脚本注入失败，请刷新页面后重试', 'error');
      event.target.disabled = false;
      event.target.textContent = '填充到页面';
      return;
    }

    // 构建标准化的发票数据对象
    const standardInvoice = {
      '发票名称': invoice['发票名称'],
      '发票号码': invoice['发票号码'],
      '金额': invoice['金额'],
      '开票日期': invoice['开票日期'],
      '文件地址': invoice['文件地址'] || ''
    };

    // 向content script发送消息
    event.target.textContent = '填充中...';
    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'fillInvoice',
      data: standardInvoice
    });

    console.log('填充响应:', response);

    if (response && response.success) {
      invoice._fillCount++;
      renderInvoiceList();
      showMessage('✅ 填充成功！', 'success');
    } else {
      showMessage('填充失败: ' + (response?.error || '未知错误'), 'error');
    }
  } catch (error) {
    console.error('填充错误:', error);
    showMessage('操作失败: ' + error.message, 'error');
  } finally {
    event.target.disabled = false;
    event.target.textContent = '填充到页面';
  }
}

/**
 * 显示消息
 */
function showMessage(text, type) {
  message.textContent = text;
  message.className = `message ${type}`;
  
  setTimeout(() => {
    message.textContent = '';
    message.className = 'message';
  }, 5000);
}

console.log('sidepanel_v2.js 加载完成');
