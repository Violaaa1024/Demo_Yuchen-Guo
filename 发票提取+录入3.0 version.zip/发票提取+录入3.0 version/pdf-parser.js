/**
 * PDF发票解析模块
 * 功能：提取发票关键字段（开票日期、发票号码、金额）
 * 版本：v5.0 - 完全解决PDF.js空格问题
 */

if (typeof pdfjsLib !== 'undefined') {
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'libs/pdf.worker.min.js';
}

class PDFInvoiceParser {
  constructor() {
    this.patterns = {
      invoiceDate: [
        /开\s*票\s*日\s*期\s*[:：\s]*(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日/,
        /(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日/,
        /(\d{4})年(\d{1,2})月(\d{1,2})日/
      ],
      invoiceNumber: [
        /发\s*票\s*号\s*码\s*[:：\s]*(\d{20})/,
        /(\d{20})/
      ],
      amount: [
        /价\s*税\s*合\s*计[\s\S]{0,30}[（(]\s*小\s*写\s*[)）]\s*[¥￥]\s*(\d+\.?\d*)/,
        /[¥￥]\s*(\d+\.\d{2})/
      ]
    };
  }

  async parsePDF(file) {
    try {
      console.log(`开始解析PDF: ${file.name}`);

      const arrayBuffer = await this.readFileAsArrayBuffer(file);
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      console.log(`PDF总页数: ${pdf.numPages}`);

      let fullText = '';
      
      for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        
        let pageText = textContent.items.map(item => item.str).join('');  // 不用空格join
        
        // ===== 关键修复：删除所有 数字-空格-数字 的空格 =====
        // 这是PDF.js的特殊格式：可能会把数字分散开
        pageText = pageText.replace(/(\d)\s+(\d)/g, '$1$2');
        
        fullText += pageText + '\n';
        console.log(`第${pageNum}页提取文本长度: ${pageText.length}`);
      }

      console.log('提取的文本总长度:', fullText.length);

      if (fullText.length < 50) {
        console.error('⚠️ PDF文本提取异常，文本过短');
        throw new Error('PDF文本内容过少');
      }

      // 提取字段
      const result = {
        '发票名称': this.extractFileName(file.name),
        '开票日期': this.extractInvoiceDate(fullText),
        '发票号码': this.extractInvoiceNumber(fullText),
        '金额': this.extractAmount(fullText),
        '_source': 'PDF',
        '_rawText': fullText
      };

      console.log('解析结果:', result);

      // 验证必填字段
      const missingFields = [];
      if (!result['发票号码']) missingFields.push('发票号码');
      if (!result['金额']) missingFields.push('金额');
      if (!result['开票日期']) missingFields.push('开票日期');

      if (missingFields.length > 0) {
        console.warn(`${file.name} 缺失字段:`, missingFields);
        result._error = `缺失字段: ${missingFields.join(', ')}`;
      }

      return result;

    } catch (error) {
      console.error(`解析PDF失败 (${file.name}):`, error);
      throw new Error(`PDF解析失败: ${error.message}`);
    }
  }

  readFileAsArrayBuffer(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (e) => reject(new Error('文件读取失败'));
      reader.readAsArrayBuffer(file);
    });
  }

  extractFileName(filename) {
    return filename.replace(/\.pdf$/i, '');
  }

  /**
   * 提取开票日期
   */
  extractInvoiceDate(text) {
    for (const pattern of this.patterns.invoiceDate) {
      const match = text.match(pattern);
      if (match) {
        let date;

        if (match.length > 2) {
          const year = match[1];
          const month = match[2].padStart(2, '0');
          const day = match[3].padStart(2, '0');
          date = `${year}年${month}月${day}日`;
        } else {
          date = match[1];
          
          if (date.includes('-') || date.includes('/')) {
            const parts = date.split(/[-\/]/);
            date = `${parts[0]}年${parts[1].padStart(2, '0')}月${parts[2].padStart(2, '0')}日`;
          } else if (date.length === 8 && /^\d+$/.test(date)) {
            date = `${date.substring(0, 4)}年${date.substring(4, 6)}月${date.substring(6, 8)}日`;
          }
        }

        // 验证年份
        const yearMatch = date.match(/(\d{4})年/);
        if (yearMatch) {
          const year = parseInt(yearMatch[1]);
          if (year >= 1900 && year <= 2100) {
            console.log('✅ 提取到开票日期:', date);
            return date;
          }
        }
      }
    }

    console.warn('❌ 未找到开票日期');
    return '';
  }

  /**
   * 提取发票号码
   */
  extractInvoiceNumber(text) {
    for (const pattern of this.patterns.invoiceNumber) {
      const match = text.match(pattern);
      if (match) {
        const num = match[1];
        const invoiceNum = num.substring(0, 20);
        console.log('✅ 提取到发票号码:', invoiceNum);
        return invoiceNum;
      }
    }

    // 兜底：找任何20位数字
    const fallback = text.match(/\d{20,}/);
    if (fallback) {
      const invoiceNum = fallback[0].substring(0, 20);
      console.log('✅ 通过兜底提取到发票号码:', invoiceNum);
      return invoiceNum;
    }

    console.warn('❌ 未找到发票号码');
    return '';
  }

  /**
   * 提取金额 - 找所有￥后面的数字.数字，取最大值
   */
  extractAmount(text) {
    // 先找"价税合计（小写）¥xxxx.xx"这种格式
    let match = text.match(/肆万贰仟圆整\s*[¥￥]\s*(\d+\.\d{2})/);
    if (match) {
      console.log('✅ 提取到金额（大写后）:', match[1]);
      return match[1];
    }

    // 再找"（小写）¥xxxx.xx"
    match = text.match(/[（(]小写[)）]\s*[¥￥]\s*(\d+\.\d{2})/);
    if (match) {
      console.log('✅ 提取到金额（小写标签）:', match[1]);
      return match[1];
    }

    // 最后的兜底：找所有￥后面的数字.数字，取最大值
    const amountMatches = text.match(/[¥￥]\s*(\d+\.?\d*)/g);
    if (amountMatches && amountMatches.length > 0) {
      const amounts = amountMatches.map(m => {
        const num = m.replace(/[¥￥\s]/g, '');
        return { text: num, value: parseFloat(num) };
      });

      amounts.sort((a, b) => b.value - a.value);
      
      const maxAmount = amounts[0].text;
      if (!maxAmount.includes('.')) {
        return maxAmount + '.00';
      }
      
      console.log('✅ 提取到金额（最大值）:', maxAmount);
      return maxAmount;
    }

    console.warn('❌ 未找到金额');
    return '';
  }

  /**
   * 批量解析PDF文件
   */
  async parseMultiple(files, onProgress) {
    const results = [];
    const total = files.length;

    for (let i = 0; i < total; i++) {
      const file = files[i];

      if (onProgress) {
        onProgress(i, total, file.name);
      }

      try {
        const result = await this.parsePDF(file);
        results.push(result);
      } catch (error) {
        console.error(`跳过文件 ${file.name}:`, error.message);
        results.push({
          '发票名称': file.name,
          '开票日期': '',
          '发票号码': '',
          '金额': '',
          '_source': 'PDF',
          '_error': error.message
        });
      }
    }

    if (onProgress) {
      onProgress(total, total, '完成');
    }

    return results;
  }
}

// 导出全局实例
window.pdfInvoiceParser = new PDFInvoiceParser();
